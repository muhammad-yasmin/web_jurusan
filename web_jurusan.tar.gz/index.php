<?php 
	header("Location: app/index/");