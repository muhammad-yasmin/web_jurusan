<a class="btn btn-flat btn-info" id="btnModal" style="display:none;" data-toggle="modal" href='#modal'>Show Modal Message</a>
<div class="modal fade" id="modal">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">&nbsp;</h4>
			</div>
			<div class="modal-body">
				<p id="idPesanModal"></p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<a class="btn btn-flat btn-info" id="btnModalHapus" style="display:none;" data-toggle="modal" href='#modalHapus'>Show Modal Message</a>
<div class="modal fade" id="modalHapus">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">&nbsp;</h4>
			</div>
			<div class="modal-body">
				<!-- <input type="text" id="idNya" name="idNya"> -->
				<p id="idPesanModalHapus"></p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" id="btnCancel" data-dismiss="modal">Tidak</button>
				<button type="button" class="btn btn-danger" id="btnOke" data-dismiss="modal">Ya</button>
			</div>
		</div>
	</div>
</div>
