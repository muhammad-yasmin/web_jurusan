<?php 
	session_destroy();
 ?>
 <script>
window.location = "../../index/";
 </script>