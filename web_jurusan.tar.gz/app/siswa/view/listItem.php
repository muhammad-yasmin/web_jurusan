<!-- begin sidebar nav -->
<ul class="nav" id="nav">
	<li class="nav-header">Menu</li>
	<li>
		<a href="index.php?pilih=dt_diri">
			<i class="fa fa-gift"></i>
			<span>Data Diri</span>
		</a>
	</li>
	<li>
		<a href="index.php?pilih=dt_ayah">
			<i class="fa fa-gift"></i>
			<span>Data Ayah</span>
		</a>
	</li>
	<li>
		<a href="index.php?pilih=dt_ibu">
			<i class="fa fa-gift"></i>
			<span>Data Ibu</span>
		</a>
	</li>
	<li><a href="javascript:;" class="sidebar-minify-btn" data-click="sidebar-minify"><i class="fa fa-angle-double-left"></i></a></li>
</ul>