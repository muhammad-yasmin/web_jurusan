<form action="" id="formnya">
	<div class="col-md-12">
		<div class="form-group">
			<label for="nisSiswa" class="col-md-4 control-label">NIS</label>
			<div class="col-md-6">
				<input class="form-control" type="text" name="nis" id="nisSiswa" value="" autocomplete="off"/>
			</div>
		</div>
		<div class="form-group">
			<label for="namaSiswa" class="col-md-4 control-label">Nama</label>
			<div class="col-md-6">
				<input class="form-control" type="text" name="nama" id="namaSiswa" value="" autocomplete="off"/>
			</div>
		</div>
		<div class="form-group">
			<label for="alamatSiswa" class="col-md-4 control-label">Alamat</label>
			<div class="col-md-6">
				<input class="form-control" type="text" name="alamat" id="alamatSiswa" value="" autocomplete="off"/>
			</div>
		</div>
		<div class="form-group">
			<label for="passSiswa" class="col-md-4 control-label">Email</label>
			<div class="col-md-6">
				<input class="form-control" type="text" name="pass" id="emailSiswa" value="" autocomplete="off"/>
			</div>
		</div>
	</div>
</form>