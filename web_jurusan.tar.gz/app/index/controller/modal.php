<a class="btn btn-primary" id="btnShowModal" style="display:none;" data-toggle="modal" href='#modalPesan'>Trigger modal</a>
<div class="modal fade" id="modalPesan" style="display:none;">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">&nbsp;</h4>
			</div>
			<div class="modal-body">
				<p id="isimodalnya"></p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>