<?php session_destroy(); ?>
<script>window.location.replace('../index/'); </script>